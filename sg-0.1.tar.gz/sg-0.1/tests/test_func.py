import os, pytest
import sg


def test_logic_processing_returns_valid(initialized_log_file):
    result = sg.logic_processing(initialized_log_file)
    assert isinstance(result, dict)


def test_smtp_log_grabber_returns_valid(initialized_log_file):
    result = sg.smtp_log_grabber(initialized_log_file)
    inst = type(sg.LogEntry())
    assert isinstance(next(result), inst)


@pytest.fixture(autouse=True)
def initialized_log_file():
    file = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'testlog')
    f = open(file, 'w')
    f.close()

    with open(file, 'w') as f:
        f.write('Jul 10 10:09:10 srv24-s-st postfix/smtpd[27068]: 451CEDF04EB: client=unknown[213.87.122.107], '
        'sasl_method=LOGIN, sasl_username=manager30@moda-milena.ru')
        f.write('test string two')
    yield file
    os.remove(file)

#need more tests
