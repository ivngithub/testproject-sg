from distutils.core import setup

setup(
   name='sg',
   version='0.1',
   description='A useful module',
   author='ivn',
   author_email='ivn@li.ru',
   packages=['sg'],
)