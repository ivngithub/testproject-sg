import re
from collections import namedtuple

"""
smtpgrabber v 0.1
"""

SENT = 'sent'
#DEFERRED = 'deferred'
BOUNCED = 'bounced'
REJECT = 'reject'

GET_LOG_ENTRY = r'postfix\/.*]:[ 0123456789ABCDEF]+:'
GET_LOG_ENTRY_CONTAINS_SASL_METHOD = r'sasl_method=([^\s]*),'
GET_LOG_ENTRY_CONTAINS_SASL_USERNAME = r'sasl_username=([^\s]*)'
GET_LOG_ENTRY_CONTAINS_REJECT = r'reject:'
GET_LOG_ENTRY_CONTAINS_HEADER_FROM = r'from=<([^\s]*)>'
GET_LOG_ENTRY_CONTAINS_HEADER_TO = r'to=<([^\s]*)>'
GET_LOG_ENTRY_CONTAINS_HEADER_TO_STATUS = r'status=([^\s]*)'
GET_LOG_ENTRY_CONTAINS_REMOVED = r'removed'

MessageStatus = namedtuple('MessageStatus', ['status', 'description'])
LogEntry = namedtuple('LogEntry', ['id',  'sasl_method', 'sasl_username', 'reject', 'header_from', 'header_to',
                                   'removed', 'original_log_line'])
LogEntry.__new__.__defaults__ = (None, None, None, None, None, None, None, None)
HeaderTO = namedtuple('HeaderTO', ['header_to', 'status'])
ResultOfSending = namedtuple('ResultOfSending', ['trying_to_send', 'queue_id'])


class SMTPLogException(Exception):
    pass


class LogicProcessingFailure(SMTPLogException):
    def __str__(self):
        return 'error processing log entry'


def smtp_log_grabber(file):
    buffer = set()

    with open(file, 'r') as f:
        for i, line in enumerate(f, start=1):
            original_log_line = '{}. {}'.format(i, line)
            search = re.search(GET_LOG_ENTRY, line)

            if search:
                log_entry = re.split(GET_LOG_ENTRY, line, maxsplit=1)[1].strip()
                id_queue = re.split(':', search.group(0))[1].strip()

                if id_queue in buffer:

                    if re.search(GET_LOG_ENTRY_CONTAINS_REJECT, log_entry):
                        buffer.remove(id_queue)

                        yield LogEntry(id=id_queue,
                                       header_from=re.search(GET_LOG_ENTRY_CONTAINS_HEADER_FROM, log_entry).group(1),
                                       header_to=[HeaderTO(header_to=re.search(GET_LOG_ENTRY_CONTAINS_HEADER_TO,
                                                                              log_entry).group(1), status='reject')],
                                       original_log_line=original_log_line)

                    elif re.search(GET_LOG_ENTRY_CONTAINS_HEADER_FROM, log_entry):

                        yield LogEntry(id=id_queue,
                                       header_from=re.search(GET_LOG_ENTRY_CONTAINS_HEADER_FROM, log_entry).group(1) or 'noname',
                                       header_to=[],
                                       original_log_line=original_log_line)

                    elif re.search(GET_LOG_ENTRY_CONTAINS_HEADER_TO, log_entry):

                        yield LogEntry(id=id_queue,
                                       header_to=[HeaderTO(header_to=re.search(GET_LOG_ENTRY_CONTAINS_HEADER_TO,
                                                                              log_entry).group(1),
                                                          status=re.search(GET_LOG_ENTRY_CONTAINS_HEADER_TO_STATUS,
                                                                              log_entry).group(1))],
                                       original_log_line=original_log_line)

                    elif re.search(GET_LOG_ENTRY_CONTAINS_REMOVED, log_entry):
                        buffer.remove(id_queue)

                        yield LogEntry(id=id_queue, removed=True, original_log_line=original_log_line)
                    else:
                        pass


                elif re.search(GET_LOG_ENTRY_CONTAINS_SASL_METHOD, log_entry) \
                        and re.search(GET_LOG_ENTRY_CONTAINS_SASL_USERNAME, log_entry):
                    buffer.add(id_queue)

                    yield LogEntry(id=id_queue,
                                   sasl_method=re.search(GET_LOG_ENTRY_CONTAINS_SASL_METHOD, log_entry).group(1),
                                   sasl_username=re.search(GET_LOG_ENTRY_CONTAINS_SASL_USERNAME, log_entry).group(1),
                                   header_to=[], original_log_line=original_log_line)


def logic_processing(file):
    tmp_before_result = {}
    result = {}

    for el in smtp_log_grabber(file):
        if el.id and el.sasl_method and el.sasl_username:
            tmp_before_result.update({el.id: el})

        elif el.id and el.reject:
            to_emails = ResultOfSending(trying_to_send=el.header_to, queue_id=el.id)
            if el.header_from not in result:
                result[el.header_from] = [to_emails]

            else:
                result[el.header_from].append(to_emails)
            tmp_before_result.pop(el.id)

        elif el.id and el.header_from:
            tmp_before_result[el.id] = tmp_before_result[el.id]._replace(
                header_from=tmp_before_result[el.id].sasl_username if el.header_from == 'noname' else el.header_from)

        elif el.id and el.header_to:

            try:
                tmp_before_result[el.id].header_to.extend(el.header_to)
            except:
                raise LogicProcessingFailure

        elif el.id and el.removed:
            log_entry = tmp_before_result[el.id]
            to_emails = ResultOfSending(trying_to_send=log_entry.header_to, queue_id=log_entry.id)

            if log_entry.header_from not in result:
                result[log_entry.header_from] = [to_emails]
            else:
                result[log_entry.header_from].append(to_emails)
            tmp_before_result.pop(el.id)

        else:
            raise LogicProcessingFailure

    return result


def show_results(result):
    counted = {}


    for key, item in result.items():
        c = {'count_sent': 0,
             'count_failure': 0,
             }
        counted[key] = c

        for el in item:
            for k in el.trying_to_send:
                if k.status == SENT:
                    c['count_sent'] += 1
                elif k.status == BOUNCED or k.status == REJECT:
                    c['count_failure'] += 1

    return counted


if __name__ == '__main__':

    r = logic_processing('maillog')
    print(show_results(r))
